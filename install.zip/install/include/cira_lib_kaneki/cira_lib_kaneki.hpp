#ifndef cira_lib_kaneki_HPP
#define cira_lib_kaneki_HPP

#include <QString>
#include <QJsonObject>
#include <QObject>
#include <QTimer>
#include <QLabel>
#include <QTreeWidget>

#ifdef WIN32
#include <cira_lib_kaneki_export.h>
#endif

class cira_lib_kaneki : public QObject
{

  Q_OBJECT

#ifndef WIN32
public:
  static QString BUBBLEBEE_KANEKI;
  QString str_;
  cira_lib_kaneki();
  static void run_stein();
  static void run_stein2();
  QJsonObject run_stein_plugin(QString p);
  static const QJsonObject run_stein_edu(QString p);
  static QString get_martha();
  static QString get_martha2();
  static QTimer *t;
  static qint64 number_a;
  static QLabel *lb_;

  static QWidget *parent;

  static bool is_nvidia_jetson;

  static bool getOPTIMUS();
  static const QJsonObject getOPTIMUS_();
  static const QJsonObject getOPTIMUS2_();

  static double get_peter();

  static QString scyt_e(QString d);

  static std::vector<QTreeWidget *> treeWidgetNodeModels;
  static void hdds(QString str);

private slots:
  void t_();

private:
  static QJsonObject JSO_OPTIMUS_KANEKI;
  static QJsonObject JSO_OPTIMUS_KANEKI2;

#else
public:
  static CIRA_LIB_KANEKI_EXPORT QString BUBBLEBEE_KANEKI;
  QString str_;
  cira_lib_kaneki();
  static CIRA_LIB_KANEKI_EXPORT void run_stein();
  static CIRA_LIB_KANEKI_EXPORT void run_stein2();
  static CIRA_LIB_KANEKI_EXPORT const QJsonObject run_stein_edu(QString p);
  QJsonObject run_stein_plugin(QString p);
  static CIRA_LIB_KANEKI_EXPORT QString get_martha();
  static CIRA_LIB_KANEKI_EXPORT QString get_martha2();
  static CIRA_LIB_KANEKI_EXPORT QTimer *t;
  static CIRA_LIB_KANEKI_EXPORT qint64 number_a;
  static CIRA_LIB_KANEKI_EXPORT QLabel *lb_;

  static CIRA_LIB_KANEKI_EXPORT QWidget *parent;

  static CIRA_LIB_KANEKI_EXPORT bool is_nvidia_jetson;

  static CIRA_LIB_KANEKI_EXPORT bool getOPTIMUS();
  static CIRA_LIB_KANEKI_EXPORT const QJsonObject getOPTIMUS_();
  static CIRA_LIB_KANEKI_EXPORT const QJsonObject getOPTIMUS2_();

  static CIRA_LIB_KANEKI_EXPORT double get_peter();

  static CIRA_LIB_KANEKI_EXPORT QString scyt_e(QString d);

  static CIRA_LIB_KANEKI_EXPORT std::vector<QTreeWidget *> treeWidgetNodeModels;
  static CIRA_LIB_KANEKI_EXPORT void hdds(QString str);

private slots:
  void t_();

private:
  static CIRA_LIB_KANEKI_EXPORT QJsonObject JSO_OPTIMUS_KANEKI;
  static CIRA_LIB_KANEKI_EXPORT QJsonObject JSO_OPTIMUS_KANEKI2;
#endif

};

#endif // cira_lib_kaneki_HPP
