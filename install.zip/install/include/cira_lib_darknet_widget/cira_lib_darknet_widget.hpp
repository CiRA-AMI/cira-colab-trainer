#ifndef cira_lib_darknet_widget_HPP
#define cira_lib_darknet_widget_HPP

#include "widget/config/dialogListConfigs.h"

class cira_lib_darknet_widget
{
public:
  cira_lib_darknet_widget();

#ifdef WIN32
  static CIRA_LIB_DARKNET_WIDGET_EXPORT DialogListConfigs *dlg_detect_lst_config;
  static CIRA_LIB_DARKNET_WIDGET_EXPORT DialogListConfigs *dlg_classif_lst_config;
  static CIRA_LIB_DARKNET_WIDGET_EXPORT DialogListConfigs *dlg_segment_lst_config;
#else
  static DialogListConfigs *dlg_detect_lst_config;
  static DialogListConfigs *dlg_classif_lst_config;
  static DialogListConfigs *dlg_segment_lst_config;
#endif

};

#endif // cira_lib_darknet_widget_HPP
