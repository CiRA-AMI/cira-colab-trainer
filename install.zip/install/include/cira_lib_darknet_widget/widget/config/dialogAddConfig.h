#ifndef DIALOGAddConfig_H
#define DIALOGAddConfig_H

#include <QDialog>
#include <QMap>
#include <QMessageBox>
#include "det_config.h"
#include "classif_config.h"
#include "segment_config.h"

namespace Ui {
class DialogAddConfig;
}

class DialogAddConfig : public QDialog
{
    Q_OBJECT

public:
    explicit DialogAddConfig(QWidget *parent = nullptr);
    ~DialogAddConfig();


    static QString last_backend_name;
    static int gpu_state;
    static QString tmp_config_path;

    bool ok = false;
    QString name;
    QMessageBox *msb;

    bool is_detection = true;
    DetConfig *det_config = NULL;
    QMap<QString, DetConfig*> map_det_cfgs;

    bool is_classif = false;
    ClassifConfig *classif_config = NULL;
    QMap<QString, ClassifConfig*> map_classif_cfgs;

    bool is_segment = false;
    SegmentConfig *segment_config = NULL;
    QMap<QString, SegmentConfig*> map_segment_cfgs;

private slots:
    void on_lineEdit_name_textChanged(const QString &arg1);

    void on_buttonBox_accepted();

private:
    Ui::DialogAddConfig *ui;
};

#endif // DIALOGAddConfig_H
