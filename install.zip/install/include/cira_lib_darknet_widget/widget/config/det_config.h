#ifndef DET_CONFIG_H
#define DET_CONFIG_H

#include <QMutex>
#include <QDebug>

#include <opencv2/opencv.hpp>
#include <cira_lib_yolo/yolo_share.hpp>
#include <cira_lib_yolo/cira_yolo_cpu.hpp>

class DetConfig
{
public:

    darknet::CiRAYolo *cira_yolo_gpu = NULL;
    CiRAYoloCPU *cira_yolo_cpu = NULL;

    QString config_path;
    //bool is_backend_gpu = false;
    QString backend_name = "CPU";
    bool is_initialized = false;

    QMutex mtx;

    double thresh, nms;
    int roi_x, roi_y, roi_width, roi_height;
    bool is_tracking;
    int frame_story, max_dist;
    bool is_draw_result, is_draw_roi, is_draw_text, show_confidence;
    int rect_thickness, font_thickness, txt_offset;
    double font_scale;

    std::vector<std::string> obj_names;
    std::vector<int> obj_counts;
    std::string obj_counts_str;

    QWidget *parent;

    DetConfig(QWidget *parent, QString config_path, QString backend_name = "CPU"){
        this->parent = parent;
        this->config_path = config_path;
        this->backend_name = backend_name;
        if(backend_name == "CUDA") {
            cira_yolo_gpu = new darknet::CiRAYolo();
            cira_yolo_gpu->detector = NULL;
        } else {
            cira_yolo_cpu = new CiRAYoloCPU();
            cira_yolo_cpu->detector = NULL;
        }
    }

    std::vector<bbox_t> infer(cv::Mat &input, QString k="");

    void delete_config() {
        if(backend_name == "CUDA") {
            if(cira_yolo_gpu->detector != NULL) cira_yolo_gpu->delete_detector(&cira_yolo_gpu->detector);
        } else {
            if(cira_yolo_cpu->detector != NULL) cira_yolo_cpu->delete_detector(&cira_yolo_cpu->detector);
        }
        is_initialized = false;
    }


    bool init();

    void reset_track_id(std::vector<unsigned int> *track_id, std::deque<std::vector<bbox_t>> *prev_bbox_vec_deque) {
      mtx.lock();
      track_id->clear();
      prev_bbox_vec_deque->clear();
      for (int j = 0; j < obj_names.size(); ++j) track_id->push_back(1);
      mtx.unlock();
    }
    int get_tracking_id(int index) { return track_id->at(index); }

    std::deque<std::vector<bbox_t>> *prev_bbox_vec_deque;
    std::vector<unsigned int> *track_id;

private:
    void applyParam();
};

#endif // DET_CONFIG_H
