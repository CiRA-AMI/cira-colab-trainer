#ifndef DialogListConfigs_H
#define DialogListConfigs_H

#include <QDialog>
#include <QMap>
#include <QEvent>
#include "dialogAddConfig.h"

#include <QListWidget>

#ifdef WIN32
#include <cira_lib_darknet_widget_export.h>
#endif

namespace Ui {
class DialogListConfigs;
}

class DialogListConfigs : public QDialog
{
    Q_OBJECT

public:
    explicit DialogListConfigs(QWidget *parent = nullptr);
    ~DialogListConfigs();

    void changeEvent(QEvent *ev) {
      if (ev->type() == QEvent::ActivationChange)
      {
          if(this->isActiveWindow()) {}
          else { if(!isPin)this->close(); }
      }
    }

    bool is_detection = true;
    bool is_classif = false;
    bool is_segment = false;

#ifdef WIN32
  static CIRA_LIB_DARKNET_WIDGET_EXPORT QMap<QString, DetConfig*> map_det_cfgs;
  static CIRA_LIB_DARKNET_WIDGET_EXPORT QMap<QString, ClassifConfig*> map_classif_cfgs;
  static CIRA_LIB_DARKNET_WIDGET_EXPORT QMap<QString, SegmentConfig*> map_segment_cfgs;
#else
    static QMap<QString, DetConfig*> map_det_cfgs;
    static QMap<QString, ClassifConfig*> map_classif_cfgs;
    static QMap<QString, SegmentConfig*> map_segment_cfgs;
#endif

    QListWidget *lst_widget;

    bool isPin = false;

    void setSelectedConfig(QString name);
    bool addConfigPath(QString name, QString config_path, QString backend_name = "CPU");
    void clean();

signals:
    void config_removed(QString);

private slots:
    void on_pushButton_add_clicked();

    void on_pushButton_remove_clicked();

private:
    Ui::DialogListConfigs *ui;

    bool addDetConfig(QString name, DetConfig *det_cfg);
    bool addClassifConfig(QString name, ClassifConfig *classif_cfg);
    bool addSegmentConfig(QString name, SegmentConfig *segment_cfg);
};

#endif // DialogListConfigs_H
