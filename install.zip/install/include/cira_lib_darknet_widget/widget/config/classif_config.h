#ifndef CLASSSIF_CONFIG_H
#define CLASSSIF_CONFIG_H

#include <QMutex>

#include <opencv2/opencv.hpp>
#include <cira_lib_yolo/classifier/cira_darknet_classifier.hpp>
#include <cira_lib_yolo/classifier/cpu/cpu_cira_darknet_classifier.hpp>
//#include <cira_lib_yolo/classifier/darknet_classifier_class.hpp>

#include<QList>
#include<QWidget>

class ClassifConfig
{
public:

    darknetclassifier::CiRAClassifier *cira_classifier_gpu = NULL;
    cpudarknetclassifier::CPUCiRAClassifier *cira_classifier_cpu = NULL;

    QString config_path;
    QString backend_name = "CPU";
    bool is_initialized = false;

    QMutex mtx;

    double thresh;
    bool is_draw_result, is_draw_roi, is_draw_text, show_confidence;
    int rect_thickness; double font_scale; int font_thickness; int txt_offset;
    int top; bool upsampling;


    cv::Mat mat_im, mat_result;
    std::vector<cv::Mat> mat_class_map;
    QList<int> draw_classes;
    int perdict_ms;
    std::string prob_map;

    std::vector<std::string> obj_names;
    std::vector<cv::Scalar> labels_color;

    QWidget *parent;

    ClassifConfig(QWidget *parent, QString config_path, QString backend_name = "CPU"){
        this->parent = parent;
        this->config_path = config_path;
        this->backend_name = backend_name;
        if(backend_name == "CUDA") {
            cira_classifier_gpu = new darknetclassifier::CiRAClassifier();
            cira_classifier_gpu->classifier = NULL;
        } else {
            cira_classifier_cpu = new cpudarknetclassifier::CPUCiRAClassifier();
            cira_classifier_cpu->classifier = NULL;
        }
    }

    std::vector<result_t> infer(cv::Mat &input);

    void delete_config() {
        if(backend_name == "CUDA") {
            if(cira_classifier_gpu->classifier != NULL) cira_classifier_gpu->delete_classifier();
        } else {
            if(cira_classifier_cpu->classifier != NULL) cira_classifier_cpu->delete_classifier();
        }
        is_initialized = false;
    }


    bool init();
    void draw_boxes(cv::Mat &input);

private:
    void applyParam();
};

#endif // CLASSSIF_CONFIG_H
