#ifndef SEGMENT_CONFIG_H
#define SEGMENT_CONFIG_H

#include <QMutex>

#include <opencv2/opencv.hpp>
#include <cira_lib_yolo/segmenter/cira_darknet_segmenter.hpp>
#include <cira_lib_yolo/segmenter/cpu/cpu_cira_darknet_segmenter.hpp>

#include<QList>
#include<QWidget>

class SegmentConfig
{
public:

    darknetsegmenter::CiRASegmenter *cira_segmenter_gpu = NULL;
    cpudarknetsegmenter::CPUCiRASegmenter *cira_segmenter_cpu = NULL;

    QString config_path;
    QString backend_name = "CPU";
    bool is_initialized = false;

    QMutex mtx;

    float thresh;
    int top = 1;
    bool is_draw_result = true;
    bool is_draw_roi = true;
    bool is_draw_text = true;
    bool show_confidence = true;
    int rect_thickness = 2;
    double font_scale = 1.2;
    int font_thickness = 2;
    int txt_offset = 10;

    std::vector<std::string> obj_names;
    std::vector<cv::Scalar> labels_color;

    QWidget *parent;

    SegmentConfig(QWidget *parent, QString config_path, QString backend_name = "CPU"){
        this->parent = parent;
        this->config_path = config_path;
        this->backend_name = backend_name;
        if(backend_name == "CUDA") {
            cira_segmenter_gpu = new darknetsegmenter::CiRASegmenter();
            cira_segmenter_gpu->segmenter = NULL;
        } else {
            cira_segmenter_cpu = new cpudarknetsegmenter::CPUCiRASegmenter();
            cira_segmenter_cpu->segmenter = NULL;
        }
    }

    cv::Mat mat_segment;
    cv::Mat mat_segment_rgb;
    std::vector<cv::Mat> mat_segment_classes;
    void infer(cv::Mat &input);

    void delete_config() {
        if(backend_name == "CUDA") {
            if(cira_segmenter_gpu->segmenter != NULL) cira_segmenter_gpu->delete_segmenter();
        } else {
            if(cira_segmenter_cpu->segmenter != NULL) cira_segmenter_cpu->delete_segmenter();
        }
        is_initialized = false;
    }


    bool init();
    void draw_boxes(cv::Mat &input);

private:
    void applyParam();
};

#endif // SEGMENT_CONFIG_H
