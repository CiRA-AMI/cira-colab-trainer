#ifndef CIRA_LIB_DARKNET_SUPPORT_HPP
#define CIRA_LIB_DARKNET_SUPPORT_HPP

#include <opencv2/imgproc.hpp>

class cira_lib_darknet_support
{
public:
  cira_lib_darknet_support();

#ifdef WIN32
  static CIRA_LIB_DARKNET_WIDGET_EXPORT cv::Mat resizeKeepAspectRatio(const cv::Mat &input, const cv::Size &dstSize, const cv::Scalar &bgcolor , int &top_, int &left_);
#else
  static cv::Mat resizeKeepAspectRatio(const cv::Mat &input, const cv::Size &dstSize, const cv::Scalar &bgcolor , int &top_, int &left_);
#endif

};

#endif // CIRA_DARKNET_SUPPORT_HPP
