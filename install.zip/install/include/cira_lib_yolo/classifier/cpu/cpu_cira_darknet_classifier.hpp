#ifndef CPU_CIRA_DARKNET_CLASSIFIER_HPP
#define CPU_CIRA_DARKNET_CLASSIFIER_HPP

#include <QString>

#include "cpu_darknet_classifier_class.hpp"
#include <opencv2/opencv.hpp>
#include <mutex>
#include <fstream>

#ifdef _WIN32
#include <cira_lib_yolo_export.h>
#endif

namespace cpudarknetclassifier {

static float colors[6][3] = { {1,0,1}, {0,0,1},{0,1,1},{0,1,0},{1,1,0},{1,0,0} };

static float get_color(int c, int x, int max)
{
    float ratio = ((float)x/max)*5;
    int i = floor(ratio);
    int j = ceil(ratio);
    ratio -= i;
    float r = (1-ratio) * colors[i][c] + ratio*colors[j][c];
    //printf("%f\n", r);
    return r;
}

static std::vector<std::string> objects_names_from_file(std::string const filename) {
  std::ifstream file(filename);
  std::vector<std::string> file_lines;
  if (!file.is_open()) return file_lines;
  for(std::string line; getline(file, line);) {
    QString line_ = QString::fromStdString(line);
    line_ =  line_.remove("\r");
    file_lines.push_back(line_.toStdString());
  }
  return file_lines;
}



class CPUCiRAClassifier
{
public:

  CPUClassifier *classifier = NULL;
  std::vector<std::string> obj_names;
  std::vector<cv::Scalar> labels_color;
  std::mutex mtx;

  //drawing
  int offset_w = 0, offset_h = 0;
  bool is_scale_exp = true;
  double scale_exp_w = 1;
  double scale_exp_h = 1;

  bool is_landmark_detection = false;
  bool is_draw_result = true;
  bool is_draw_roi = true;
  bool is_draw_text = true;
  bool show_confidence = true;
  int rect_thickness = 2;
  double font_scale = 1.2;
  int font_thickness = 2;
  int txt_offset = 10;
  //#####################

  float thresh;

  CPUCiRAClassifier() {}
  void init(std::string cfg_file, std::string names_file, std::string weights_file, bool is_use_ncnn = false, bool is_use_vulkan = false);

  std::vector<result_t> result_vec;
  void run_classify(cv::Mat &mat_input, cv::Mat &mat_result, std::vector<cv::Mat> &mat_class_map, double thresh, int top, bool upsampling_to_input_size);
  void draw_boxes(cv::Mat &mat_result);
  void delete_classifier();

};

} //end namespace

#endif // CIRA_DARKNET_CLASSIFIER_HPP
