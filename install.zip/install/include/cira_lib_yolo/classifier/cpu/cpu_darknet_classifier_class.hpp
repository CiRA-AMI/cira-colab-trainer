#ifndef DARKNET_CPUClassifier_CLASS_HPP
#define DARKNET_CPUClassifier_CLASS_HPP

#pragma once
#include <memory>
#include <vector>
#include <deque>
#include <algorithm>

#include <opencv2/dnn.hpp>

#ifdef OPENCV
#include <opencv2/opencv.hpp>			// C++
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#endif	// OPENCV

#ifdef YOLODLL_EXPORTS
#if defined(_MSC_VER)
#define YOLODLL_API __declspec(dllexport)
#else
#define YOLODLL_API __attribute__((visibility("default")))
#endif
#else
#if defined(_MSC_VER)
#define YOLODLL_API __declspec(dllimport)
#else
#define YOLODLL_API
#endif
#endif

#include <QString>
#include "../darknet_classifier_class.hpp"

#include "cpu_ncnn_classifier_class.hpp"

namespace cpudarknetclassifier {


class CPUClassifier {

  cv::dnn::Net net;
  std::vector<cv::String> outputLayerNames;

public:

  CPUClassifier(std::string cfg_filename, std::string weight_filename, bool is_use_ncnn = false, bool is_use_vulkan = false);
  ~CPUClassifier();

  std::vector<result_t> classify(cv::Mat mat, std::vector<cv::Mat> &mat_class_map, double thresh, int top, bool upsampling_to_input_size);
  int get_net_width() const;
  int get_net_height() const;
  int classes = 1;

  int l_out_h = 8;
  int l_out_w = 8;
  int l_out_c = 1000;
  int net_h = 256;
  int net_w = 256;

public:
  std::string config_path;
  int predict_ms;
  std::string prob_map;
  std::string _cfg_filename, _weight_filename;

private:
  NCNNClassifier *classifier_ncnn = NULL;

  bool is_use_ncnn = false;
  bool is_arch_ARM = false;

};

} //end namespace

#endif // DARKNET_CPUClassifier_CLASS_HPP
