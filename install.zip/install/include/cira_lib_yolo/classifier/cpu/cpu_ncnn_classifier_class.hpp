#ifndef DARKNET_NCNNClassifier_CLASS_HPP
#define DARKNET_NCNNClassifier_CLASS_HPP

#pragma once
#include <memory>
#include <vector>
#include <deque>
#include <algorithm>

#include <opencv2/dnn.hpp>

#ifdef OPENCV
#include <opencv2/opencv.hpp>			// C++
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#endif	// OPENCV

#ifdef YOLODLL_EXPORTS
#if defined(_MSC_VER)
#define YOLODLL_API __declspec(dllexport)
#else
#define YOLODLL_API __attribute__((visibility("default")))
#endif
#else
#if defined(_MSC_VER)
#define YOLODLL_API __declspec(dllimport)
#else
#define YOLODLL_API
#endif
#endif

#include <QString>
#include "../darknet_classifier_class.hpp"

namespace ncnn {
  class Net;
}


namespace cpudarknetclassifier {


class NCNNClassifier {

  ncnn::Net *net;
  std::vector<cv::String> outputLayerNames;

public:

  NCNNClassifier(std::string cfg_filename, std::string weight_filename, int net_w, int net_h, bool is_use_vulkan = false);
  ~NCNNClassifier();

  std::vector<result_t> classify(cv::Mat mat, std::vector<cv::Mat> &mat_class_map, double thresh, int top, bool upsampling_to_input_size);
  int get_net_width() const;
  int get_net_height() const;
  int classes = 1;

  int l_index = -1;
  int l_out_h = 8;
  int l_out_w = 8;
  int l_out_c = 1000;
  int net_h = 256;
  int net_w = 256;

  int target_size = 0;

public:
  std::string config_path;
  int predict_ms;
  std::string prob_map;
  std::string _cfg_filename, _weight_filename;
};

} //end namespace

#endif // DARKNET_NCNNClassifier_CLASS_HPP
