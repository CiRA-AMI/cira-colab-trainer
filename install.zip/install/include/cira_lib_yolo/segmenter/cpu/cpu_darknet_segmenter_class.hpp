#ifndef CPU_DARKNET_SEGMENTER_CLASS_HPP
#define CPU_DARKNET_SEGMENTER_CLASS_HPP

#pragma once
#include <memory>
#include <vector>
#include <deque>
#include <algorithm>

#include <opencv2/dnn.hpp>

#ifdef OPENCV
#include <opencv2/opencv.hpp>			// C++
#include "opencv2/highgui/highgui_c.h"	// C
#include "opencv2/imgproc/imgproc_c.h"	// C
#include <opencv2/imgproc/imgproc.hpp>
#endif	// OPENCV

#ifdef YOLODLL_EXPORTS
#if defined(_MSC_VER)
#define YOLODLL_API __declspec(dllexport)
#else
#define YOLODLL_API __attribute__((visibility("default")))
#endif
#else
#if defined(_MSC_VER)
#define YOLODLL_API __declspec(dllimport)
#else
#define YOLODLL_API
#endif
#endif

namespace cpudarknetsegmenter {


struct result_t {
  unsigned int index;
  float prob;
};

struct image_t {
  int h;						// height
  int w;						// width
  int c;						// number of chanels (3 - for RGB)
  float *data;				// pointer to the image data
};


class Segmenter {
  cv::dnn::Net net;
  std::vector<cv::String> outputLayerNames;
public:

  Segmenter(std::string cfg_filename, std::string weight_filename);
  ~Segmenter();

  void segment(cv::Mat mat, cv::Mat &mat_segment, cv::Mat &mat_segment_rgb, std::vector<cv::Mat> &mat_segment_classes, double thresh);
  int get_net_width() const;
  int get_net_height() const;
  int classes = 1;

  int l_out_h = 256;
  int l_out_w = 256;
  int l_out_c = 1;
  int net_h = 256;
  int net_w = 256;

public:
  std::string config_path;
  int predict_ms;
  std::string prob_map;
  std::string _cfg_filename, _weight_filename;
};

} //end namespace

#endif // DARKNET_SEGMENTER_CLASS_HPP
