#ifndef DARKNET_SEGMENTER_CLASS_HPP
#define DARKNET_SEGMENTER_CLASS_HPP

#pragma once
#include <memory>
#include <vector>
#include <deque>
#include <algorithm>


#include <opencv2/opencv.hpp>			// C++
#include "opencv2/highgui/highgui_c.h"	// C
#include "opencv2/imgproc/imgproc_c.h"	// C
#include <opencv2/imgproc/imgproc.hpp>

#ifdef OPENCV
#include <opencv2/opencv.hpp>			// C++
#include "opencv2/highgui/highgui_c.h"	// C
#include "opencv2/imgproc/imgproc_c.h"	// C
#include <opencv2/imgproc/imgproc.hpp>
#endif	// OPENCV

#ifdef YOLODLL_EXPORTS
#if defined(_MSC_VER)
#define YOLODLL_API __declspec(dllexport)
#else
#define YOLODLL_API __attribute__((visibility("default")))
#endif
#else
#if defined(_MSC_VER)
#define YOLODLL_API __declspec(dllimport)
#else
#define YOLODLL_API
#endif
#endif

namespace darknetsegmenter {


struct result_t {
  unsigned int index;
  float prob;
};

struct image_t {
  int h;						// height
  int w;						// width
  int c;						// number of chanels (3 - for RGB)
  float *data;				// pointer to the image data
};


class Segmenter {
  std::shared_ptr<void> segmenter_gpu_ptr;
public:

  Segmenter(std::string cfg_filename, std::string weight_filename, int gpu_id = 0);
  ~Segmenter();

  void segment(std::shared_ptr<image_t> img, cv::Mat &mat_segment, cv::Mat &mat_segment_rgb, std::vector<cv::Mat> &mat_segment_classes, double thresh);
  static image_t load_image(std::string image_filename);
  static void free_image(image_t m);
  int get_net_width() const;
  int get_net_height() const;
  int classes = 1;

#ifdef OPENCV

  void segment(cv::Mat mat, cv::Mat &mat_segment, cv::Mat &mat_segment_rgb, std::vector<cv::Mat> &mat_segment_classes, double thresh)
  {
      if(mat.data == NULL)
          throw std::runtime_error("Image is empty");
      auto image_ptr = mat_to_image_resize(mat);
      segment(image_ptr, mat_segment, mat_segment_rgb, mat_segment_classes, thresh);
  }

  std::shared_ptr<image_t> mat_to_image_resize(cv::Mat &mat) const
  {
    if (mat.data == NULL) return std::shared_ptr<image_t>(NULL);

    cv::Size network_size = cv::Size(get_net_width(), get_net_height());
    cv::Mat det_mat;
    if (mat.size() != network_size)
        cv::resize(mat, det_mat, network_size);
    else
        det_mat = mat;  // only reference is copied

    return mat_to_image(det_mat);
  }

  static std::shared_ptr<image_t> mat_to_image(cv::Mat &img_src)
  {
    cv::Mat img;
    if (img_src.channels() == 4) cv::cvtColor(img_src, img, cv::COLOR_RGBA2BGR);
    else if (img_src.channels() == 3) cv::cvtColor(img_src, img, cv::COLOR_RGB2BGR);
    else if (img_src.channels() == 1) cv::cvtColor(img_src, img, cv::COLOR_GRAY2BGR);
    else std::cerr << " Warning: img_src.channels() is not 1, 3 or 4. It is = " << img_src.channels() << std::endl;
    std::shared_ptr<image_t> image_ptr(new image_t, [](image_t *img) { free_image(*img); delete img; });
    *image_ptr = mat_to_image_custom(img);
    return image_ptr;
  }

private:

  static image_t mat_to_image_custom(cv::Mat mat)
  {
      int w = mat.cols;
      int h = mat.rows;
      int c = mat.channels();
      image_t im = make_image_custom(w, h, c);
      unsigned char *data = (unsigned char *)mat.data;
      int step = mat.step;
      for (int y = 0; y < h; ++y) {
          for (int k = 0; k < c; ++k) {
              for (int x = 0; x < w; ++x) {
                  im.data[k*w*h + y*w + x] = data[y*step + x*c + k] / 255.0f;
              }
          }
      }
      return im;
  }

  static image_t make_empty_image(int w, int h, int c)
  {
      image_t out;
      out.data = 0;
      out.h = h;
      out.w = w;
      out.c = c;
      return out;
  }

  static image_t make_image_custom(int w, int h, int c)
  {
      image_t out = make_empty_image(w, h, c);
      out.data = (float *)calloc(h*w*c, sizeof(float));
      return out;
  }

#endif	// OPENCV


public:
  std::string config_path;
  int predict_ms;
  std::string prob_map;
  std::string _cfg_filename, _weight_filename;
};

} //end namespace

#endif // DARKNET_SEGMENTER_CLASS_HPP
