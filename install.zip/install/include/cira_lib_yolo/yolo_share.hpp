#ifndef YOLO_SHARE_HPP
#define YOLO_SHARE_HPP

#include "cira_yolo.hpp"

#ifdef _WIN32
#include <cira_lib_yolo_export.h>
#endif

class YoloShare {

public:

#ifdef _WIN32
    static CIRA_LIB_YOLO_EXPORT Detector *object_detector;
    static CIRA_LIB_YOLO_EXPORT Detector *landmark_detector;
    static CIRA_LIB_YOLO_EXPORT QString tmp_object_wg_path;
    static CIRA_LIB_YOLO_EXPORT QString tmp_landmark_wg_path;
#else
    static Detector *object_detector;
    static Detector *landmark_detector;
    static QString tmp_object_wg_path;
    static QString tmp_landmark_wg_path;
#endif


  YoloShare();

  static cv::Scalar get_label_color(int index, int label_size);

};

#endif // YOLO_SHARE_HPP
