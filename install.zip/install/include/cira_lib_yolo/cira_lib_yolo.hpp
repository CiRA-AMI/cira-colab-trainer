#ifndef CIRA_LIB_YOLO_HPP
#define CIRA_LIB_YOLO_HPP

class GlobalCiRALibYolo {
public:

    GlobalCiRALibYolo()  {}
    void run_export(char *cfgfile, char *weightfile, char *out, char *img_path);
    bool is_gpu_ok();

#ifdef _WIN32
    static CIRA_LIB_YOLO_EXPORT GlobalCiRALibYolo *GlobalCiRALibYoloObject;
#else
    static GlobalCiRALibYolo *GlobalCiRALibYoloObject;
#endif

};

#endif // CIRA_LIB_YOLO_HPP
