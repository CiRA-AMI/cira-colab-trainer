#ifndef YOLO_CLASS_NCNN_HPP
#define YOLO_CLASS_NCNN_HPP

#include "yolo_class.hpp"

#include <fstream>
#include <sstream>
#include <iostream>

#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>

namespace ncnn {
  class Net;
}

class DetectorNCNN {

public:

    float nms = .4;
    float thresh = .5;

    struct Object
    {
        cv::Rect_<float> rect;
        int label;
        float prob;
    };

    ncnn::Net *net;
    std::vector<Object> objects;
    int target_size = 0;

    int net_w = 416, net_h = 416;

    bool is_use_vulkan = false;

    //teerawat
    std::vector<std::string> obj_names;

    DetectorNCNN(std::string cfg_filename, std::string weight_filename, std::string classesFile, int net_w, int net_h, bool is_use_vulkan = false);
    DetectorNCNN(std::string cfg_filename, std::string weight_filename, int net_w, int net_h, bool is_use_vulkan = false);
    ~DetectorNCNN();

    std::vector<bbox_t> detect(cv::Mat mat, bool use_mean = false);
    int detect_yolov4(const cv::Mat& bgr, std::vector<Object>& objects);
    int draw_objects(const cv::Mat& bgr, const std::vector<Object>& objects);
    std::vector<bbox_t> postprocess(cv::Mat& frame, const std::vector<cv::Mat>& outs);

    float *run_net(cv::Mat &mat_in, int &n_outputs);
};


#endif // YOLO_CLASS_NCNN_HPP
