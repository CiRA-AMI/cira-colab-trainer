#ifndef YOLO_CLASS_CPU_HPP
#define YOLO_CLASS_CPU_HPP

#include "yolo_class.hpp"

#include <fstream>
#include <sstream>
#include <iostream>

#include <opencv2/dnn.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>

#include "yolo_class_ncnn.hpp"

#ifdef VITISAI
class DetectorVitisAI;
#endif

class DetectorCPU {

public:

    float nms = .4;
    float thresh = .5;

    cv::dnn::Net net;
    std::vector<cv::String> outputLayerNames;

    cv::Mat tmp;
    int net_w = 416, net_h = 416;

    bool is_use_size_416 = false;

    //teerawat
    std::vector<std::string> obj_names;
    std::string config_path = "";

    DetectorCPU(std::string cfg_filename, std::string weight_filename, std::string classesFile, bool is_use_ncnn = false, bool is_use_vulkan = false);
    ~DetectorCPU();

    std::vector<bbox_t> detect(cv::Mat mat, bool use_mean = false);
    std::vector<cv::String> getOutputsNames(const cv::dnn::Net& net);
    std::vector<bbox_t> postprocess(cv::Mat& frame, const std::vector<cv::Mat>& outs);



    DetectorNCNN *detector_ncnn = NULL;

#ifdef VITISAI
    DetectorVitisAI *detector_vitis_ai = NULL;
#endif

private:
    bool is_arch_ARM = false;
    bool is_use_ncnn = false;
    bool is_vitis_ai = false;
};


#endif // YOLO_CLASS_CPU_HPP
