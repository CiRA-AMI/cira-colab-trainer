#ifndef CIRA_YOLO_CPU_HPP
#define CIRA_YOLO_CPU_HPP

#include <QMutex>
#include <QObject>
#include <QStringList>

#include "yolo_class_cpu.hpp"

#ifdef _WIN32
#include <cira_lib_yolo_export.h>
#endif

class CiRAYoloCPU : public QObject {

  Q_OBJECT

  float colors[6][3] = { {1,0,1}, {0,0,1},{0,1,1},{0,1,0},{1,1,0},{1,0,0} };

  float get_color(int c, int x, int max)
  {
      float ratio = ((float)x/max)*5;
      int i = floor(ratio);
      int j = ceil(ratio);
      ratio -= i;
      float r = (1-ratio) * colors[i][c] + ratio*colors[j][c];
      //printf("%f\n", r);
      return r;
  }

public:

  QMutex mutex;

  DetectorCPU *detector = NULL;
  std::vector<std::string> obj_names;
  std::vector<int> obj_counts;
  std::string obj_counts_str;

  bool is_landmark_detection = false;
  bool is_draw_result = true;
  bool is_draw_roi = true;
  bool is_draw_text = true;
  bool show_confidence = true;
  int rect_thickness = 2;
  double font_scale = 1.2;
  int font_thickness = 2;
  int txt_offset = 10;

  QStringList filter;

  std::vector<bbox_t> result_vec, thread_result_vec;
  cv::Mat transp;

  float thresh;
  float nms;
  cv::Rect roi;

  bool is_tracking = false;
  int frame_story = 5;
  int max_dist = 150;
  std::vector<bbox_t> tracking_id(std::vector<bbox_t> &cur_bbox_vec, bool const change_history,
      int const frames_story, int const max_dist);
  std::deque<std::vector<bbox_t>> *prev_bbox_vec_deque;
  std::vector<unsigned int> *track_id;

  void run_detector_(cv::Mat &mat_input, cv::Mat &mat_result, QString k="");

  CiRAYoloCPU();
  CiRAYoloCPU(DetectorCPU *detector, bool is_landmark_detection = false);
  void init(std::string cfg_file, std::string names_file, std::string weights_file, DetectorCPU **detector_, bool is_use_ncnn = false, bool is_use_vulkan = false);
  void init_();
  void run_detector(cv::Mat &mat_input, cv::Mat &mat_result);
  void run_detector_track(cv::Mat &mat_input, cv::Mat &mat_result, double nms, double thresh, int const frame_story = 5, int const max_dist = 150);
  void draw_boxes(cv::Mat &mat_result);
  std::vector<cv::Scalar> labels_color;
  void delete_detector(DetectorCPU **detector_);

};


#endif // CIRA_YOLO_CPU_HPP
