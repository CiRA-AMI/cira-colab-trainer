
#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <queue>
#include <fstream>
#include <thread>
#include <atomic>
#include <mutex>              // std::mutex, std::unique_lock
#include <condition_variable> // std::condition_variable
#include <QMutex>
#include <QObject>
#include <QStringList>

#include "yolo_support.hpp"

#ifdef _WIN32
#include <cira_lib_yolo_export.h>
#endif

namespace darknet {

static float colors[6][3] = { {1,0,1}, {0,0,1},{0,1,1},{0,1,0},{1,1,0},{1,0,0} };

static float get_color(int c, int x, int max)
{
    float ratio = ((float)x/max)*5;
    int i = floor(ratio);
    int j = ceil(ratio);
    ratio -= i;
    float r = (1-ratio) * colors[i][c] + ratio*colors[j][c];
    //printf("%f\n", r);
    return r;
}

class CiRAYolo : public QObject {
  Q_OBJECT
public:

#ifdef _WIN32
  static CIRA_LIB_YOLO_EXPORT Detector *object_detector;
  static CIRA_LIB_YOLO_EXPORT Detector *landmark_detector;
#else
  static Detector *object_detector;
  static Detector *landmark_detector;
#endif

  QMutex mutex;

  Detector *detector = NULL;
  std::vector<std::string> obj_names;
  std::vector<int> obj_counts;
  std::string obj_counts_str;

  int offset_w = 0, offset_h = 0;
  bool is_scale_exp = true;
  double scale_exp_w = 1;
  double scale_exp_h = 1;

  bool is_landmark_detection = false;
  bool is_draw_result = true;
  bool is_draw_roi = true;
  bool is_draw_text = true;
  bool show_confidence = true;
  int rect_thickness = 2;
  double font_scale = 1.2;
  int font_thickness = 2;
  int txt_offset = 10;

  QStringList filter;

  std::vector<bbox_t> result_vec, thread_result_vec;
  cv::Mat transp;

  bool is_tracking = false;
  int frame_story = 5;
  int max_dist = 150;
  std::vector<bbox_t> tracking_id(std::vector<bbox_t> &cur_bbox_vec, bool const change_history,
      int const frames_story, int const max_dist);
  std::deque<std::vector<bbox_t>> *prev_bbox_vec_deque;
  std::vector<unsigned int> *track_id;

    float thresh;
    float nms;
    cv::Rect roi;
    void run_detector_(cv::Mat &mat_input, cv::Mat &mat_result, QString k="");

  CiRAYolo();
  CiRAYolo(Detector *detector, bool is_landmark_detection = false);
  bool init(std::string cfg_file, std::string names_file, std::string weights_file, Detector **detector_);
  void init_();
  void run_detector_track(cv::Mat &mat_input, cv::Mat &mat_result, double nms, double thresh, int const frame_story = 5, int const max_dist = 150);
  void run_detector(cv::Mat &mat_input, cv::Mat &mat_result, double nms, double thresh);
  void draw_boxes(cv::Mat &mat_result);
  std::vector<cv::Scalar> labels_color;
  void delete_detector(Detector **detector_);

};


} //namespace darknet
