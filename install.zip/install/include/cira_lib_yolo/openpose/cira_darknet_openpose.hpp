#ifndef CIRA_DARKNET_OPENPOSE_HPP
#define CIRA_DARKNET_OPENPOSE_HPP

#include "darknet_openpose.hpp"
#include <opencv2/opencv.hpp>
#include <mutex>

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

namespace darknet_openpose {


class CiRAOpenPose
{
public:

  OpenPose *openpose = NULL;
  std::mutex mtx;

  int net_inw = 0;
  int net_inh = 0;
  int net_outw = 0;
  int net_outh = 0;

  float thresh;

  CiRAOpenPose() {}
  void init(std::string cfg_file, std::string weights_file);

  //std::vector<result_t> result_vec;
  void run(cv::Mat &mat_input, cv::Mat &mat_result);
  void delete_openpose();

};

} //end namespace

#endif // CIRA_DARKNET_OPENPOSE_HPP
