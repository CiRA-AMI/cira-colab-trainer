#ifndef DARKNET_OPENPOSE_HPP
#define DARKNET_OPENPOSE_HPP

#pragma once
#include <memory>
#include <vector>
#include <deque>
#include <algorithm>

#ifdef OPENCV
#include <opencv2/opencv.hpp>			// C++
#include "opencv2/highgui/highgui_c.h"	// C
#include "opencv2/imgproc/imgproc_c.h"	// C
#include <opencv2/imgproc/imgproc.hpp>
#endif	// OPENCV

#ifdef _WIN32
#include <cira_lib_yolo_export.h>
#endif

namespace darknet_openpose {

struct result_t {
  unsigned int index;
  float prob;
};

struct image_t {
  int h;						// height
  int w;						// width
  int c;						// number of chanels (3 - for RGB)
  float *data;				// pointer to the image data
};


class OpenPose {
  std::shared_ptr<void> openpose_gpu_ptr;
public:

  OpenPose(std::string cfg_filename, std::string weight_filename,
           int *inw,
           int *inh,
           int *outw,
           int *outh, int gpu_id = 0);
  ~OpenPose();

  std::vector<result_t> detect(std::shared_ptr<image_t> img);
  static image_t load_image(std::string image_filename);
  static void free_image(image_t m);
  int get_net_width() const;
  int get_net_height() const;
  int classes = 1;

  float *run_net(float *indata);

#ifdef OPENCV

  std::vector<result_t> detect(cv::Mat mat)
  {
      if(mat.data == NULL)
          throw std::runtime_error("Image is empty");
      auto image_ptr = mat_to_image_resize(mat);
      return detect(image_ptr);
  }

  std::shared_ptr<image_t> mat_to_image_resize(cv::Mat &mat) const
  {
    if (mat.data == NULL) return std::shared_ptr<image_t>(NULL);

    cv::Size network_size = cv::Size(get_net_width(), get_net_height());
    cv::Mat det_mat;
    if (mat.size() != network_size)
        cv::resize(mat, det_mat, network_size);
    else
        det_mat = mat;  // only reference is copied

    return mat_to_image(det_mat);
  }

  static std::shared_ptr<image_t> mat_to_image(cv::Mat &img_src)
  {
    cv::Mat img;
    if (img_src.channels() == 4) cv::cvtColor(img_src, img, cv::COLOR_RGBA2BGR);
    else if (img_src.channels() == 3) cv::cvtColor(img_src, img, cv::COLOR_RGB2BGR);
    else if (img_src.channels() == 1) cv::cvtColor(img_src, img, cv::COLOR_GRAY2BGR);
    else std::cerr << " Warning: img_src.channels() is not 1, 3 or 4. It is = " << img_src.channels() << std::endl;
    std::shared_ptr<image_t> image_ptr(new image_t, [](image_t *img) { free_image(*img); delete img; });
    *image_ptr = mat_to_image_custom(img);
    return image_ptr;
  }

private:

  static image_t mat_to_image_custom(cv::Mat mat)
  {
      int w = mat.cols;
      int h = mat.rows;
      int c = mat.channels();
      image_t im = make_image_custom(w, h, c);
      unsigned char *data = (unsigned char *)mat.data;
      int step = mat.step;
      for (int y = 0; y < h; ++y) {
          for (int k = 0; k < c; ++k) {
              for (int x = 0; x < w; ++x) {
                  im.data[k*w*h + y*w + x] = data[y*step + x*c + k] / 255.0f;
              }
          }
      }
      return im;
  }

  static image_t make_empty_image(int w, int h, int c)
  {
      image_t out;
      out.data = 0;
      out.h = h;
      out.w = w;
      out.c = c;
      return out;
  }

  static image_t make_image_custom(int w, int h, int c)
  {
      image_t out = make_empty_image(w, h, c);
      out.data = (float *)calloc(h*w*c, sizeof(float));
      return out;
  }

#endif	// OPENCV


public:
  std::string config_path;
  int predict_ms;
  std::string prob_map;
  std::string _cfg_filename, _weight_filename;
};



} // end namespace

#endif // DARKNET_OPENPOSE_HPP
